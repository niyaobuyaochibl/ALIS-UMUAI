# ALIS — Reproduction Package (Anonymized for Double-Anonymous Review)

This repository accompanies the manuscript *"ALIS: Adaptive Knowledge-Interface
Selection for LLM-Assisted Recommender Systems"* submitted to ACM TKDD under
double-anonymous review. **All author, institution, and funding information has
been removed.** A non-anonymized version with full provenance will be released
upon acceptance.

This is a lightweight package: it contains the core method/experiment scripts and
the aggregated result tables needed to reproduce every table in the paper. Raw
user-interaction rows are **not** redistributed (public-dataset license terms);
only model-derived artifacts and aggregated metrics are included.

## Contents

```
scripts/   core method and experiment code
results/   aggregated CSVs that back each table (grouped by research question)
requirements.txt
```

## Mapping from paper to artifacts

| Paper item | Script | Result file(s) |
|---|---|---|
| RQ1 — ALIS selection & sensitivity (Tables 1–2) | `scripts/run_adaptive_interface_selector.py` | `results/rq1_alis/alis_selected_interfaces.csv`, `alis_sensitivity_grid.csv`, `candidate_interface_metrics.csv` |
| RQ2 — main utility/reliability/faithfulness (Tables 3–4) | `scripts/run_egpr_profile_repair_pilot.py`, `scripts/compare_ml1m_fair_direct_candidates.py` | `results/rq2_main/ml1m_fair_summary.csv`, `table2_recommendation_performance.csv`, `table3_reliability.csv`, `table1_profile_faithfulness.csv` |
| RQ3 — evidence repair | `scripts/run_egpr_profile_repair_pilot.py` | `results/rq2_main/*` (faithfulness vs utility) |
| RQ4 — SASRec backbone transfer | `scripts/run_ml1m_sasrec_profile_rerank.py` | `results/rq4_sasrec/table2_recommendation_performance.csv` |
| RQ5 — LLMRank + cross-provider (Table 5) | `scripts/run_ml1m_reranking_baselines.py`, `scripts/run_amazon_books_reranking_baselines.py`, `scripts/finalize_rq5_table.py` | `results/rq5_crossprovider/*_summary.csv` |
| RQ6 — per-user selection (Table 6) | `scripts/predictive_alis.py` | `results/rq6_peruser/predictive_alis_ml1m.txt` |
| Content baseline (Eq. 1) | `scripts/run_*_reranking_baselines.py` (`--methods content`) | included in the per-RQ summaries |
| Direct reranker & LLM API client | `scripts/run_amazon_books_direct_rerank_pilot.py` (`DirectReranker`) | — |

## Reproducing the per-user analysis (RQ6, no API, no GPU)

`predictive_alis.py` learns the per-user interface selector with scikit-learn
only (no LLM call, no GPU). It expects the full per-user artifact tree
(per-user NDCG CSVs, the content top-list `.npy`, and the base-score `.npz`); to
keep this review package small, only the **aggregated multi-seed output** is
included here (`results/rq6_peruser/predictive_alis_ml1m.txt`), and the
per-interface NDCG CSVs are under `results/rq2_main/`. The complete artifact tree
needed to re-run the driver end-to-end is provided in the full package released
upon acceptance.

```bash
pip install -r requirements.txt
python scripts/predictive_alis.py     # requires the full results/ tree
```

## Running the LLM experiments

LLM calls use an OpenAI-compatible chat API. Set the provider key via environment
variable (no keys are stored in this repository):

```bash
export DEEPSEEK_API_KEY=...     # or MOONSHOT_API_KEY / OPENAI_API_KEY
python scripts/run_ml1m_reranking_baselines.py --methods content llmrank --provider deepseek
```

## Datasets

ML-1M (GroupLens), the Amazon review corpus, and the Yelp Open Dataset are used
from their original public distributors under their respective license terms.
Candidate sets are produced by a LightGCN base recommender over the full item
corpus (no negative sampling).

## Notes

- This anonymized package is intended for the review phase only.
- Sentence embeddings use a public Sentence-BERT model; the content reranker uses
  token overlap and requires no model download.
