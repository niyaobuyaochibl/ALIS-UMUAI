# ALIS — revision R1 supplement

This archive supplements `repro_anon_alis.zip` with the scripts and outputs of the
analyses added in the first revision. Unpack it into the root of the original
replication package; paths below are relative to that root. Section and table
numbers refer to the revised manuscript.

No profile or ranking of the original runs was regenerated. All analyses except
the claim audit reuse the logged per-user rankings of the original runs and make
no LLM calls. The claim audit and the judge calibration call three independent LLM judges.

## Scripts (`scripts/`)

| Script | Produces | Paper |
|---|---|---|
| `run_revision_r1.sh` | Runs the steps below except the weight/reuse sweep and the claim audit | — |
| `analyze_yelp_1000_fair_confirmatory.py`, `analyze_amazon_books_fair_confirmatory.py` | `results/revision_r1/{yelp,books}_fair/` | Per-user rankings and paired statistics for Yelp and Amazon Books |
| `run_reranking_baselines_strong.py` | `results/revision_r1/{ml1m,books}_strong/` | Token-overlap, BM25, and dense rerankers |
| `export_revision_panels.py` | `results/revision_r1/panels/` | Per-user reward panels, every user scored under every interface |
| `alis_revision_analysis.py` | `results/revision_r1/analysis/{oos_*,bootstrap_selection,paired_tests,direct_grounding_sensitivity,routing_*}.csv`, `report.md` | §6.1, Tables 5–6; Direct grounding convention (§6.1); per-user routing, nested CV (§6.7, Table 15) |
| `alis_weight_reuse_sensitivity.py` | `results/revision_r1/analysis/weight_*.csv` | Harm/disruption weights, pool composition, profile reuse horizon (§6.1, Table 7) |
| `run_llm_claim_audit.py` | `results/revision_r1/claim_audit/audit_sample.csv`, `judgments_*.jsonl` | Blind LLM-judge claim audit (§6.4) |
| `analyze_llm_claim_audit.py` | `results/revision_r1/claim_audit/*.csv` | Agreement, stratum profile, correspondence with the support score (§6.4, Table 12) |
| `run_judge_calibration.py`, `aggrefact_calibration_lib.py` | `results/revision_r1/judge_calibration/calibration_sample.csv`, `judgments_*.jsonl` | Calibration of the same judges against expert labels on LLM-AggreFact (§6.4) |
| `analyze_judge_calibration.py` | `results/revision_r1/judge_calibration/calibration_*.{csv,json}` | Balanced accuracy, Cohen's kappa with expert labels, bootstrap CIs (§6.4) |

## Claim audit (`results/revision_r1/claim_audit/`)

- `audit_sample.csv`: the 1,073 sampled claims with their support score, EGPR weight,
  governance stratum, and stratum size (seed 2026, 134 claims per domain and stratum).
- `judgments_<model>.jsonl`: one record per claim and judge (label, sensitivity flag,
  short reason, token usage, and cost). Judges: `anthropic/claude-haiku-5.5`,
  `openai/gpt-6-luna`, `google/gemini-3.8-flash` via OpenRouter, temperature 0.
- `agreement.csv`: pairwise Cohen's kappa and Fleiss' kappa.
- `stratum_profile.csv`: majority-label shares by domain and stratum (Table 12).
- `domain_summary.csv`: population-weighted rates, AUC and Spearman correlation of the
  EGPR weight against judged support.
- `claim_level_majority.csv`, `label_distribution_by_model.csv`, `sensitive_by_type.csv`.

The judge prompt is defined in `run_llm_claim_audit.py` (`SYSTEM`, `INSTRUCTIONS`,
`user_prompt`). Judges see the same 20 most recent interactions the profile generator
saw; for Amazon Books the script checks this against the generator's prompt-cache keys.
To re-run, set `OPENROUTER_API_KEY` and run

```
python scripts/run_llm_claim_audit.py --dry-run     # sample and show one prompt
python scripts/run_llm_claim_audit.py               # judge all claims (about US$1.2)
python scripts/analyze_llm_claim_audit.py
```

Raw user histories are not included, consistent with the original package.

## Judge calibration (`results/revision_r1/judge_calibration/`)

The three audit judges were run on 1,100 expert-labelled claims from the test split of
LLM-AggreFact (Tang et al., EMNLP 2024): 50 supported and 50 unsupported claims from each
of its 11 source datasets (seed 2026; documents longer than about 6,000 tokens excluded).
The prompt adapts the audit prompt from a user history to a grounding document
(`aggrefact_calibration_lib.py`); labels, instructions, and decoding are unchanged.

- `calibration_sample.csv`: the sampled claims, identified by `key` = `<dataset>:<row in
  the test split>`, with source dataset, expert label, and document length. The claim and
  document text are not included; the benchmark is distributed by its authors on Hugging
  Face (`lytang/LLM-AggreFact`) under access conditions.
- `judgments_<model>.jsonl`: one record per claim and judge, as for the audit.
- `calibration_summary.csv`: balanced accuracy and Cohen's kappa against the expert
  labels for each judge and the majority of three, with stratified bootstrap 95% CIs.
- `calibration_by_dataset.csv`, `calibration_results.json`: per-dataset balanced accuracy,
  inter-judge Fleiss' kappa, and the labels given to expert-supported claims.

To re-run, accept the access conditions of `lytang/LLM-AggreFact`, log in with
`huggingface-cli login`, set `OPENROUTER_API_KEY`, and run

```
python scripts/run_judge_calibration.py --dry-run  # download, sample, show one prompt
python scripts/run_judge_calibration.py            # judge all claims (about US$1.4)
python scripts/analyze_judge_calibration.py
```
